create
    definer = root@localhost procedure createEmployee(IN nombreEmpleado varchar(25), IN apellidoEmpleado varchar(25),
                                                      IN telefonoEmpleado varchar(12), IN usernameEmpleado varchar(25),
                                                      IN passwordEmpleado varchar(100),
                                                      IN horaInicioEmpleado varchar(25), IN horaFinEmpleado varchar(25),
                                                      IN diaDescansoEmpleado varchar(10),
                                                      IN nombreCargoEmpleado varchar(30))
INSERT INTO personal (nombre, apellidos, telefono, usuario, password, horaInicio, horaFin, diaDescanso, nombreCargo)
VALUES (nombreEmpleado, apellidoEmpleado, telefonoEmpleado, usernameEmpleado, passwordEmpleado, horaInicioEmpleado, horaFinEmpleado, diaDescansoEmpleado, nombreCargoEmpleado);

