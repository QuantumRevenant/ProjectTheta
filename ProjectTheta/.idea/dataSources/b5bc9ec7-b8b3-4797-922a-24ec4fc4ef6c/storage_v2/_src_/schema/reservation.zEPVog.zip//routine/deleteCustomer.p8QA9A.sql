create
    definer = root@localhost procedure deleteCustomer(IN idCliente int)
DELETE FROM cliente
WHERE idCliente = idCliente;

