create
    definer = root@localhost procedure createCategory(IN nuevoNombre varchar(25))
INSERT INTO categoria(nombre)
	VALUES(nuevoNombre);

