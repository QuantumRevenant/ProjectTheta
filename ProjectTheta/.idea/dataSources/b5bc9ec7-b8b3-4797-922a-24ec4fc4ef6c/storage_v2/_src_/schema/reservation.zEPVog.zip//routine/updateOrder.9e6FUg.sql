create
    definer = root@localhost procedure updateOrder(IN idPedido int, IN descripcion varchar(200),
                                                   IN total double(255, 2), IN fechaPedido varchar(50),
                                                   IN status varchar(50), IN idPersonal int, IN idTipoPedido int,
                                                   IN idCliente int, IN idTipoPago int, IN igv double(255, 2))
UPDATE pedidos
    SET descripcion = descripcion, total = total, fechaPedido = fechaPedido, idPersonal = idPersonal,
        idTipoPedido = idTipoPedido, idCliente = idCliente, idTipoPago = idTipoPago, igv = igv, Status = status
    WHERE idPedido = idPedido;

