create
    definer = root@localhost procedure customerList()
SELECT * FROM cliente;

