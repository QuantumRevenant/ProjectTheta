create
    definer = root@localhost procedure updateMenu(IN idMenu int, IN idCategoria int, IN tipo varchar(25),
                                                  IN descripcion varchar(200), IN precio double(255, 2))
UPDATE menu
    SET idCategoria = idCategoria, tipo = tipo, descripcion = descripcion, precio = precio
    WHERE idMenu = idMenu;

