create
    definer = root@localhost procedure deleteOrder(IN idPedido int)
DELETE FROM pedidos
    WHERE idPedido = idPedido;

