create
    definer = root@localhost procedure createCustomer(IN nombreCliente varchar(25), IN apellidoCliente varchar(25),
                                                      IN dniCliente varchar(8), IN telefonoCliente varchar(25),
                                                      IN direccionCliente varchar(100))
INSERT INTO cliente (nombre, apellido, dni, telefono, direccion)
VALUES (nombreCliente, apellidoCliente, dniCliente, telefonoCliente, direccionCliente);

