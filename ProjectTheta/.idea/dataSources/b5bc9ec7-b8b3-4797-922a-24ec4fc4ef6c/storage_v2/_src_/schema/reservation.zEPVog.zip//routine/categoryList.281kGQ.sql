create
    definer = root@localhost procedure categoryList()
SELECT * FROM categoria;

