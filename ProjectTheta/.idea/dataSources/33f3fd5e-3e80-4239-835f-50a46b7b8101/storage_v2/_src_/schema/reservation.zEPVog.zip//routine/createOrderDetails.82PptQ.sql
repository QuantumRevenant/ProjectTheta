create
    definer = root@localhost procedure createOrderDetails(IN idPedido int, IN idMenu int, IN cantidadPlatos int,
                                                          IN subtotal double(255, 2))
INSERT INTO detallepedido (idPedido, idMenu, cantidadPlatos, subtotal)
    VALUES (idPedido, idMenu, cantidadPlatos, subtotal);

