create
    definer = root@localhost procedure menuList()
SELECT * FROM menu;

