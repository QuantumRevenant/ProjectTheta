create
    definer = root@localhost procedure updateCustomer(IN idClient int, IN nombreCliente varchar(25),
                                                      IN apellidoCliente varchar(25), IN dniCliente varchar(8),
                                                      IN telefonoCliente varchar(25), IN direccionCliente varchar(100))
UPDATE cliente
    SET nombre = nombreCliente, apellido = apellidoCliente, dni = dniCliente,
        telefono = telefonoCliente, direccion = direccionCliente
    WHERE idCliente = idClient;

