create
    definer = root@localhost procedure saveOrder(IN idPedido int, IN descripcion varchar(200), IN total double(255, 2),
                                                 IN fechaPedido varchar(50), IN status varchar(50), IN idPersonal int,
                                                 IN idTipoPedido int, IN idCliente int, IN idTipoPago int,
                                                 IN igv double(255, 2))
INSERT INTO pedidos (idPedido, descripcion, total, fechaPedido , idPersonal, idTipoPedido, idCliente, idTipoPago, igv, status)
    VALUES (idPedido, descripcion, total, fechaPedido, idPersonal, idTipoPedido, idCliente, idTipoPago, igv, status);

