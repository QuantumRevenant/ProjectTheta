create
    definer = root@localhost procedure deleteCustomer(IN idClient int)
DELETE FROM cliente
WHERE idCliente = idClient;

