create
    definer = root@localhost procedure deleteEmployeeById(IN p_idPersonal int)
DELETE FROM personal
    WHERE idPersonal=p_idPersonal;

