create
    definer = root@localhost procedure createMenu(IN idMenu int, IN idCategoria int, IN tipo varchar(25),
                                                  IN descripcion varchar(200), IN precio double(255, 2))
INSERT INTO menu (idMenu, idCategoria, tipo, descripcion, precio)
    VALUES (idMenu, idCategoria, tipo, descripcion, precio);

