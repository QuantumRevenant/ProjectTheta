create
    definer = root@localhost procedure orderDetailsList()
SELECT * FROM detallepedido;

